import os
os.chdir("C:/Users/vtvas/Documents/Modules/CS7050/Workshops/Week9")


