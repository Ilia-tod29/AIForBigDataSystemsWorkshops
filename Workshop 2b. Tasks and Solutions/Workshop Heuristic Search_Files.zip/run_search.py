from def_run import *


run_find_min_edge()


run_breadth_first_tree_search()


run_breadth_first_graph_search()


run_best_first_graph_search()


run_uniform_cost_search()


run_depth_first_tree_search()


run_depth_first_graph_search()


run_iterative_deepening_search()


run_depth_limited_search()


run_bidirectional_search()


run_astar_search()


run_recursive_best_first_search()


run_simulated_annealing()


run_and_or_graph_search()


run_online_dfs_agent()


run_LRTAStarAgent()


run_genetic_algorithm()