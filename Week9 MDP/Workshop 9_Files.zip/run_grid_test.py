"""
Markov Decision Processes (Chapter 17)
Testing the MDP and POMDP in a grid problem

"""

import random

from collections import defaultdict

import numpy as np

from utils import vector_add, orientations, turn_right, turn_left, print_table

from def_grid_test import *


test_value_iteration()

test_policy_iteration()

test_best_policy()

pi = best_policy(sequential_decision_environment, value_iteration(sequential_decision_environment, .01))

"""
pi = {(0, 1): (0, 1),
 (1, 2): (1, 0),
 (3, 2): None,
 (0, 0): (0, 1),
 (3, 0): (-1, 0),
 (3, 1): None,
 (2, 1): (0, 1),
 (2, 0): (0, 1),
 (2, 2): (1, 0),
 (1, 0): (1, 0),
 (0, 2): (1, 0)}
"""

sequential_decision_environment.to_arrows(pi)
sequential_decision_environment.to_arrows(policy_iteration(sequential_decision_environment))

"""
s= 
>   >      >   .
^   None   ^   .
^   >      ^   <

"""

test_transition_model()

test_pomdp_value_iteration()

test_pomdp_value_iteration2()

"""
s = { 'a' : {	'plan1' : [(0.2, 'a'), (0.3, 'b'), (0.3, 'c'), (0.2, 'd')],
                'plan2' : [(0.4, 'a'), (0.15, 'b'), (0.45, 'c')],
                'plan3' : [(0.2, 'a'), (0.5, 'b'), (0.3, 'c')],
                 },
      'b' : {	'plan1' : [(0.2, 'a'), (0.6, 'b'), (0.2, 'c'), (0.1, 'd')],
                'plan2' : [(0.6, 'a'), (0.2, 'b'), (0.1, 'c'), (0.1, 'd')],
                'plan3' : [(0.3, 'a'), (0.3, 'b'), (0.4, 'c')],
                },
        'c' : {	'plan1' : [(0.3, 'a'), (0.5, 'b'), (0.1, 'c'), (0.1, 'd')],
                'plan2' : [(0.5, 'a'), (0.3, 'b'), (0.1, 'c'), (0.1, 'd')],
                'plan3' : [(0.1, 'a'), (0.3, 'b'), (0.1, 'c'), (0.5, 'd')],
                },
    }
"""