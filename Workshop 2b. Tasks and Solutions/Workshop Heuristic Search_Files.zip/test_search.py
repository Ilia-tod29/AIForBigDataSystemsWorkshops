from def_test import *


test_find_min_edge()



test_breadth_first_tree_search()



test_breadth_first_graph_search()



test_best_first_graph_search()



test_uniform_cost_search()



test_depth_first_tree_search()



test_depth_first_graph_search()



test_iterative_deepening_search()



test_depth_limited_search()



test_bidirectional_search()



test_astar_search()



test_recursive_best_first_search()


test_simulated_annealing()


test_and_or_graph_search()


test_online_dfs_agent()


test_LRTAStarAgent()


test_genetic_algorithm()